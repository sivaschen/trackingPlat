export const baseDomain = {
    httpUrl: process.env.NODE_ENV === "development" ? "/api" : "http://webbo.yunjiwulian.com"
}